<?php 

include "config.php";

  if (isset($_POST['submit3'])) {

    $naam = $_POST['naam'];
    $omschrijving = $_POST['omschrijving'];
    $vergoeding = $_POST['vergoeding'];
    $gewichtGram = $_POST['gewichtGram'];

    $sql = "INSERT INTO `apparaten`(`naam`, `omschrijving`, `vergoeding`, `gewichtGram`) VALUES ('$naam','$omschrijving','$vergoeding','$gewichtGram')";

    $result = $conn->query($sql);

    if ($result == TRUE) {
      echo "Nieuw apparaat toegevoegd";
    }else{
      echo "Error:". $sql . "<br>". $conn->error;
    } 

    $conn->close(); 

  }

?>

<!DOCTYPE html>

<html>

<body>

<h2>Apparaten</h2>

<form action="" method="POST">

  <fieldset>

    Naam:<br>
    <input type="text" name="naam">
    <br>

    Omschrijving:<br>
    <input type="text" name="omschrijving" placeholder="Omschrijving">
    <br>

    Vergoeding:<br>
    <input type="int" name="vergoeding">
    <br>

    Gewicht in grammen:<br>
    <input type="int" name="gewichtGram">
    <br>

    <input type="submit" name="submit3" value="submit">

  </fieldset>

</form>

</body>

</html>