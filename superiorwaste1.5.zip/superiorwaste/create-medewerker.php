<?php 

include "config.php";

  if (isset($_POST['submit3'])) {

    $naam = $_POST['naam'];
    $wachtwoord = $_POST['wachtwoord'];
    $emailadres = $_POST['emailadres'];

    $sql = "INSERT INTO `medewerkers`(`naam`, `wachtwoord`, `emailadres`) VALUES ('$naam','$wachtwoord','$emailadres')";

    $result = $conn->query($sql);

    if ($result == TRUE) {
      echo "Nieuwe medewerker toegevoegd";
    }else{
      echo "Error:". $sql . "<br>". $conn->error;
    } 

    $conn->close(); 

  }

?>

<!DOCTYPE html>

<html>

<body>

<h2>Medewerkers toevoegen</h2>

<form action="" method="POST">

  <fieldset>

    Naam:<br>
    <input type="text" name="naam">
    <br>

    wachtwoord:<br>
    <input type="password" name="wachtwoord" placeholder="******">
    <br>

    Emaildres:<br>
    <input type="text" name="ema
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    iladres">
    <br>

    <input type="submit" name="submit3" value="submit">

  </fieldset>

</form>

</body>

</html>